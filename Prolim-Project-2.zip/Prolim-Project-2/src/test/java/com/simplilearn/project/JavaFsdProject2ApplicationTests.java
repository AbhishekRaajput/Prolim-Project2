package com.simplilearn.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaFsdProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
